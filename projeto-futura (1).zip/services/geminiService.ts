
import { GoogleGenAI, Type } from "@google/genai";
import { SoilNutrients } from "../types";

export const analyzeSoilData = async (nutrients: SoilNutrients, crop: string) => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Analise os seguintes dados de solo para a cultura de ${crop}:
  - pH: ${nutrients.ph || 'N/A'}
  - Fósforo (P): ${nutrients.p || 'N/A'} mg/dm³
  - Potássio (K): ${nutrients.k || 'N/A'} cmolc/dm³
  - Matéria Orgânica (MO): ${nutrients.mo || 'N/A'}%
  - Cálcio (Ca): ${nutrients.ca || 'N/A'}
  - Magnésio (Mg): ${nutrients.mg || 'N/A'}

  Por favor, forneça uma análise técnica resumida, recomendação de calagem e adubação (se necessário) e alertas de deficiência ou excesso.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: "Você é um agrônomo especialista em fertilidade de solo e nutrição de plantas. Forneça respostas técnicas, precisas e profissionais em Português do Brasil.",
        temperature: 0.7,
      },
    });

    return response.text;
  } catch (error) {
    console.error("Erro na análise Gemini:", error);
    return "Não foi possível realizar a análise automática no momento.";
  }
};
