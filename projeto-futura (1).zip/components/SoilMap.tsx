
import React, { useEffect, useState, useRef } from 'react';
import { Farm, Field, SamplePoint, SampleStatus } from '../types';

interface SoilMapProps {
  farm: Farm;
  farms: Farm[];
  setFarms: (farms: Farm[]) => void;
  selectedField: Field | null;
}

const SoilMap: React.FC<SoilMapProps> = ({ farm, farms, setFarms, selectedField }) => {
  const [activeFieldIdA, setActiveFieldIdA] = useState<string>(selectedField?.id || farm.fields[0]?.id || '');
  const [activeFieldIdB, setActiveFieldIdB] = useState<string>('');
  const [comparisonMode, setComparisonMode] = useState(false);
  const [selectedPoint, setSelectedPoint] = useState<SamplePoint | null>(null);
  const [viewLayer, setViewLayer] = useState<'sampling' | 'boundary' | 'ndvi'>('sampling');
  const [isUploadingMap, setIsUploadingMap] = useState(false);

  const mapContainerARef = useRef<HTMLDivElement>(null);
  const mapContainerBRef = useRef<HTMLDivElement>(null);
  const mapARef = useRef<any>(null);
  const mapBRef = useRef<any>(null);
  const markersARef = useRef<any[]>([]);
  const markersBRef = useRef<any[]>([]);
  const geojsonLayerARef = useRef<any>(null);
  const geojsonLayerBRef = useRef<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const statusColors: any = {
    [SampleStatus.PENDING]: '#f59e0b',
    [SampleStatus.COLLECTED]: '#3b82f6',
    [SampleStatus.IN_LAB]: '#8b5cf6',
    [SampleStatus.COMPLETED]: '#10b981',
  };

  const handleMapImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingMap(true);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const content = evt.target?.result as string;
        const geojson = JSON.parse(content);
        
        // Atualiza o talhão ativo com o novo limite
        const updatedFarms = farms.map(f => {
          if (f.id === farm.id) {
            return {
              ...f,
              fields: f.fields.map(field => {
                if (field.id === activeFieldIdA) {
                  return { ...field, boundary: geojson };
                }
                return field;
              })
            };
          }
          return f;
        });

        setFarms(updatedFarms);
        setViewLayer('boundary');
        alert("Mapa importado com sucesso!");
      } catch (err) {
        console.error("Erro ao importar mapa:", err);
        alert("Erro ao ler arquivo GeoJSON. Certifique-se de que é um formato válido.");
      } finally {
        setIsUploadingMap(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsText(file);
  };

  useEffect(() => {
    if (!mapContainerARef.current) return;

    if (!mapARef.current) {
      mapARef.current = (window as any).L.map(mapContainerARef.current).setView([-18.91, -48.27], 14);
      (window as any).L.tileLayer('https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', { attribution: 'Google' }).addTo(mapARef.current);
      
      mapARef.current.on('move', () => {
        if (mapBRef.current && comparisonMode) {
          mapBRef.current.setView(mapARef.current.getCenter(), mapARef.current.getZoom(), { animate: false });
        }
      });
    }

    if (comparisonMode && mapContainerBRef.current && !mapBRef.current) {
      mapBRef.current = (window as any).L.map(mapContainerBRef.current).setView(mapARef.current.getCenter(), mapARef.current.getZoom());
      (window as any).L.tileLayer('https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', { attribution: 'Google' }).addTo(mapBRef.current);
      
      mapBRef.current.on('move', () => {
        if (mapARef.current) {
          mapARef.current.setView(mapBRef.current.getCenter(), mapBRef.current.getZoom(), { animate: false });
        }
      });
    }

    renderMapData(mapARef.current, markersARef, geojsonLayerARef, activeFieldIdA);
    if (comparisonMode && mapBRef.current) {
      renderMapData(mapBRef.current, markersBRef, geojsonLayerBRef, activeFieldIdB || activeFieldIdA);
    }

    return () => {
      if (!comparisonMode && mapBRef.current) {
        mapBRef.current.remove();
        mapBRef.current = null;
      }
    };
  }, [activeFieldIdA, activeFieldIdB, comparisonMode, farm, viewLayer]);

  const renderMapData = (mapInstance: any, markersRef: React.MutableRefObject<any[]>, geoLayerRef: React.MutableRefObject<any>, fieldId: string) => {
    if (!mapInstance) return;
    
    // Limpar marcadores
    markersRef.current.forEach(m => mapInstance.removeLayer(m));
    markersRef.current = [];
    
    // Limpar GeoJSON anterior
    if (geoLayerRef.current) {
      mapInstance.removeLayer(geoLayerRef.current);
      geoLayerRef.current = null;
    }

    const field = farm.fields.find(f => f.id === fieldId);
    if (!field) return;

    // Renderizar Limites/Polígonos (Mapas Importados)
    if (field.boundary && (viewLayer === 'boundary' || viewLayer === 'sampling')) {
      geoLayerRef.current = (window as any).L.geoJSON(field.boundary, {
        style: {
          color: '#10b981',
          weight: 3,
          fillColor: '#10b981',
          fillOpacity: 0.1
        }
      }).addTo(mapInstance);
    }

    // Renderizar Pontos de Amostragem
    field.points.forEach(point => {
      const mainStatus = point.layers[0]?.status || SampleStatus.PENDING;
      const marker = (window as any).L.circleMarker([point.lat, point.lng], {
        radius: 8,
        fillColor: viewLayer === 'ndvi' ? '#4ade80' : statusColors[mainStatus],
        color: '#fff',
        weight: 2,
        opacity: 1,
        fillOpacity: 0.9
      }).addTo(mapInstance);

      marker.bindTooltip(`<b>${point.id}</b>`, { direction: 'top', className: 'text-[9px] font-bold px-1 py-0 shadow-none border-none' });
      marker.on('click', () => setSelectedPoint(point));
      markersRef.current.push(marker);
    });

    // Ajustar zoom se houver dados
    const group = (window as any).L.featureGroup([...markersRef.current, ...(geoLayerRef.current ? [geoLayerRef.current] : [])]);
    if (group.getLayers().length > 0) {
      mapInstance.fitBounds(group.getBounds().pad(0.1));
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-180px)] space-y-4">
      {/* Barra de Ferramentas Superior */}
      <div className="bg-white p-3 rounded-2xl shadow-sm border border-slate-200 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="flex flex-col">
             <label className="text-[10px] font-bold text-slate-400 uppercase ml-1">Mapa Principal</label>
             <select 
              className="bg-slate-50 border border-slate-200 rounded-lg p-2 text-sm outline-none font-semibold text-slate-700"
              value={activeFieldIdA}
              onChange={(e) => setActiveFieldIdA(e.target.value)}
            >
              {farm.fields.map(f => <option key={f.id} value={f.id}>{f.name} ({f.season})</option>)}
            </select>
          </div>

          {comparisonMode && (
            <>
              <div className="h-8 w-[1px] bg-slate-200 self-end mb-1"></div>
              <div className="flex flex-col">
                <label className="text-[10px] font-bold text-emerald-600 uppercase ml-1">Comparar com</label>
                <select 
                  className="bg-emerald-50 border border-emerald-100 rounded-lg p-2 text-sm outline-none font-semibold text-emerald-800 animate-in fade-in"
                  value={activeFieldIdB}
                  onChange={(e) => setActiveFieldIdB(e.target.value)}
                >
                  <option value="">Selecione talhão/safra...</option>
                  {farm.fields.map(f => <option key={f.id} value={f.id}>{f.name} ({f.season})</option>)}
                </select>
              </div>
            </>
          )}
        </div>

        <div className="flex items-center space-x-2">
           <div className="flex bg-slate-100 p-1 rounded-xl mr-2">
              <button 
                onClick={() => setViewLayer('sampling')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${viewLayer === 'sampling' ? 'bg-white shadow text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
              >
                VISTA GERAL
              </button>
              <button 
                onClick={() => setViewLayer('boundary')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${viewLayer === 'boundary' ? 'bg-white shadow text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
              >
                CONTORNOS
              </button>
              <button 
                onClick={() => setViewLayer('ndvi')}
                className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${viewLayer === 'ndvi' ? 'bg-white shadow text-emerald-600' : 'text-slate-500 hover:text-slate-700'}`}
              >
                NDVI
              </button>
          </div>
          
          <input type="file" ref={fileInputRef} onChange={handleMapImport} accept=".geojson,.json" className="hidden" />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="bg-slate-900 text-white px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-2 hover:bg-black transition-all shadow-md"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
            <span>{isUploadingMap ? 'Processando...' : 'Importar Mapa'}</span>
          </button>

          <button 
            onClick={() => {
              setComparisonMode(!comparisonMode);
              if (!comparisonMode && !activeFieldIdB) setActiveFieldIdB(activeFieldIdA);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center space-x-2 ${
              comparisonMode ? 'bg-emerald-600 text-white shadow-lg' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50'
            }`}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7" /></svg>
            <span>{comparisonMode ? 'Sair da Comparação' : 'Modo Comparar'}</span>
          </button>
        </div>
      </div>

      {/* Áreas de Mapa */}
      <div className="flex-1 flex gap-4 min-h-0 relative">
        <div className={`flex-1 bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden relative transition-all duration-500`}>
          <div className="absolute top-3 left-3 z-[400] bg-white/80 backdrop-blur px-2 py-1 rounded-lg text-[10px] font-bold text-slate-500 border border-slate-200 uppercase">
             {farm.fields.find(f => f.id === activeFieldIdA)?.season || 'Safra N/A'}
          </div>
          <div ref={mapContainerARef} className="h-full w-full" />
        </div>

        {comparisonMode && (
          <div className="flex-1 bg-white rounded-3xl shadow-sm border border-emerald-200 overflow-hidden relative animate-in slide-in-from-right-10 duration-500">
            <div className="absolute top-3 left-3 z-[400] bg-emerald-600 px-2 py-1 rounded-lg text-[10px] font-bold text-white border border-emerald-700 uppercase">
               {farm.fields.find(f => f.id === (activeFieldIdB || activeFieldIdA))?.season || 'Safra N/A'}
            </div>
            <div ref={mapContainerBRef} className="h-full w-full" />
          </div>
        )}

        {selectedPoint && (
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-sm bg-white/95 backdrop-blur-md p-5 rounded-3xl shadow-2xl border border-emerald-100 animate-in slide-in-from-bottom-10">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h4 className="font-bold text-slate-800">Ponto {selectedPoint.id}</h4>
                <p className="text-[10px] text-slate-400 font-mono">Status: {selectedPoint.layers[0]?.status}</p>
              </div>
              <button onClick={() => setSelectedPoint(null)} className="text-slate-400 hover:text-slate-600">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="flex gap-2">
              <button className="flex-1 py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-bold uppercase tracking-wider">Ver Análise Lab</button>
              <button className="flex-1 py-2 bg-slate-100 text-slate-600 rounded-xl text-[10px] font-bold uppercase tracking-wider">Etiqueta RFID</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SoilMap;
