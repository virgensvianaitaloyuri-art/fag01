
import React from 'react';
import { ViewState, Farm } from '../types';

interface SidebarProps {
  activeView: ViewState;
  setActiveView: (view: ViewState) => void;
  selectedFarm: Farm;
  setSelectedFarm: (farm: Farm) => void;
  farms: Farm[];
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, selectedFarm, setSelectedFarm, farms }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Painel de Controle', icon: 'M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z' },
    { id: 'farms', label: 'Gestão de Clientes', icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z' },
    { id: 'samples', label: 'Mapas e Coleta', icon: 'M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7' },
    { id: 'analysis', label: 'Diagnóstico IA', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 flex flex-col hidden md:flex">
      <div className="p-6 border-b border-slate-100 flex items-center space-x-2">
        <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center text-white font-bold">A</div>
        <span className="text-xl font-bold text-slate-800 tracking-tight">AgroSolo<span className="text-emerald-600">Pro</span></span>
      </div>

      <div className="p-4 border-b border-slate-100">
        <div className="flex justify-between items-center mb-2">
          <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider">Cliente / Fazenda Ativa</label>
        </div>
        <select 
          className="w-full bg-slate-50 border border-slate-200 text-sm rounded-lg p-2 focus:ring-2 focus:ring-emerald-500 outline-none"
          value={selectedFarm.id}
          onChange={(e) => {
            const farm = farms.find(f => f.id === e.target.value);
            if (farm) setSelectedFarm(farm);
          }}
        >
          {farms.map(farm => (
            <option key={farm.id} value={farm.id}>{farm.owner} - {farm.name}</option>
          ))}
        </select>
      </div>

      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveView(item.id as ViewState)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              activeView === item.id 
                ? 'bg-emerald-50 text-emerald-700 shadow-sm border border-emerald-100' 
                : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={item.icon} />
            </svg>
            <span className="font-medium text-sm">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto">
        <div className="bg-slate-900 rounded-2xl p-4 text-white">
          <h4 className="text-xs font-bold text-emerald-400 mb-1 uppercase">Monitoramento</h4>
          <p className="text-[11px] text-slate-400 mb-3">Prestação de serviços técnica e eficiente.</p>
          <div className="text-[10px] text-slate-500 font-mono">AgroSolo Service v2.0</div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
