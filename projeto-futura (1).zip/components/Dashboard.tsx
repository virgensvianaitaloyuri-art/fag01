
import React from 'react';
import { Farm, SampleStatus, ViewState, Field } from '../types';

interface DashboardProps {
  farms: Farm[];
  setActiveView: (view: ViewState) => void;
  setSelectedField: (field: Field) => void;
  setSelectedFarm: (farm: Farm) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ farms, setActiveView, setSelectedField, setSelectedFarm }) => {
  
  const calculateFieldProgress = (field: Field) => {
    const totalLayers = field.points.reduce((acc, p) => acc + p.layers.length, 0);
    if (totalLayers === 0) return 0;
    const completedLayers = field.points.reduce((acc, p) => 
      acc + p.layers.filter(l => l.status === SampleStatus.COMPLETED || l.status === SampleStatus.IN_LAB || l.status === SampleStatus.COLLECTED).length, 0
    );
    return Math.round((completedLayers / totalLayers) * 100);
  };

  const getFieldStatusCounts = (field: Field) => {
    const layers = field.points.flatMap(p => p.layers);
    return {
      total: layers.length,
      pending: layers.filter(l => l.status === SampleStatus.PENDING).length,
      collected: layers.filter(l => l.status === SampleStatus.COLLECTED).length,
      inLab: layers.filter(l => l.status === SampleStatus.IN_LAB).length,
      completed: layers.filter(l => l.status === SampleStatus.COMPLETED).length,
    };
  };

  return (
    <div className="space-y-8 pb-12">
      {/* Resumo Global Rápido */}
      <div className="flex flex-wrap gap-4">
        <div className="bg-white px-6 py-4 rounded-2xl shadow-sm border border-slate-200 flex items-center space-x-4">
          <div className="w-10 h-10 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase">Total de Clientes</p>
            <p className="text-xl font-bold text-slate-800">{farms.length}</p>
          </div>
        </div>
        <div className="bg-white px-6 py-4 rounded-2xl shadow-sm border border-slate-200 flex items-center space-x-4">
          <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4" /></svg>
          </div>
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase">Mapeamentos Realizados</p>
            <p className="text-xl font-bold text-slate-800">{farms.reduce((acc, f) => acc + f.fields.length, 0)}</p>
          </div>
        </div>
      </div>

      {/* Grid de Clientes */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-8">
        {farms.map(farm => (
          <div key={farm.id} className="bg-white rounded-3xl shadow-sm border border-slate-200 overflow-hidden flex flex-col">
            <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-emerald-600 text-white rounded-2xl flex items-center justify-center font-bold text-xl shadow-lg shadow-emerald-200">
                  {farm.owner.charAt(0)}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-800">{farm.owner}</h3>
                  <p className="text-xs text-slate-500 font-medium">{farm.name} • {farm.location}</p>
                </div>
              </div>
              <button 
                onClick={() => { setSelectedFarm(farm); setActiveView('samples'); }}
                className="text-xs font-bold text-emerald-600 bg-emerald-50 px-4 py-2 rounded-xl hover:bg-emerald-100 transition-colors"
              >
                MODO COMPARAR
              </button>
            </div>

            <div className="p-6 flex-1 space-y-6">
              <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cronologia de Talhões</h4>
              
              <div className="space-y-4">
                {farm.fields.length === 0 ? (
                  <p className="text-sm text-slate-400 italic py-4 text-center">Nenhum talhão cadastrado para este cliente.</p>
                ) : (
                  farm.fields.map(field => {
                    const progress = calculateFieldProgress(field);
                    const stats = getFieldStatusCounts(field);
                    
                    return (
                      <div 
                        key={field.id} 
                        onClick={() => { setSelectedFarm(farm); setSelectedField(field); setActiveView('samples'); }}
                        className="group cursor-pointer bg-slate-50 hover:bg-white hover:shadow-md border border-slate-100 hover:border-emerald-100 rounded-2xl p-4 transition-all"
                      >
                        <div className="flex justify-between items-center mb-3">
                          <div className="flex flex-col">
                            <span className="text-sm font-bold text-slate-700 group-hover:text-emerald-700 transition-colors">{field.name}</span>
                            <div className="flex items-center space-x-2">
                               <span className="text-[9px] bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded font-bold uppercase">{field.season}</span>
                               <span className="text-[9px] text-slate-400 font-mono uppercase">{field.crop}</span>
                            </div>
                          </div>
                          <span className="text-xs font-bold text-slate-600">{progress}%</span>
                        </div>
                        
                        <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden mb-3 flex">
                          <div className="h-full bg-emerald-500 transition-all duration-500" style={{ width: `${(stats.completed / stats.total) * 100 || 0}%` }}></div>
                          <div className="h-full bg-purple-500 transition-all duration-500" style={{ width: `${(stats.inLab / stats.total) * 100 || 0}%` }}></div>
                          <div className="h-full bg-blue-500 transition-all duration-500" style={{ width: `${(stats.collected / stats.total) * 100 || 0}%` }}></div>
                        </div>

                        <div className="flex justify-between items-center text-[10px] font-bold text-slate-400">
                          <div className="flex space-x-3">
                             <div className="flex items-center"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 mr-1"></span> {stats.completed} OK</div>
                             <div className="flex items-center"><span className="w-1.5 h-1.5 rounded-full bg-purple-500 mr-1"></span> {stats.inLab} LAB</div>
                             <div className="flex items-center"><span className="w-1.5 h-1.5 rounded-full bg-blue-500 mr-1"></span> {stats.collected} COL</div>
                          </div>
                          <div className="text-slate-300">Total: {stats.total} amostras</div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-between text-[11px] font-bold text-slate-500">
               <span>Total de Registros: {farm.fields.length}</span>
               <span className="text-emerald-600 uppercase">Linha do Tempo Disponível</span>
            </div>
          </div>
        ))}

        {farms.length === 0 && (
          <div className="col-span-full py-20 bg-white rounded-3xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-center">
            <h3 className="text-lg font-bold text-slate-800">Nenhum cliente cadastrado</h3>
            <button onClick={() => setActiveView('farms')} className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-bold mt-4 shadow-lg">Cadastrar Primeiro Cliente</button>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
