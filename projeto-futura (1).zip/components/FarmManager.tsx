
import React, { useState, useRef } from 'react';
import { Farm, Field } from '../types';

interface FarmManagerProps {
  farms: Farm[];
  setFarms: (farms: Farm[]) => void;
  selectedFarm: Farm;
  setSelectedFarm: (farm: Farm) => void;
}

const FarmManager: React.FC<FarmManagerProps> = ({ farms, setFarms, selectedFarm, setSelectedFarm }) => {
  const [showModal, setShowModal] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [newFarm, setNewFarm] = useState({ name: '', owner: '', location: '', plannedFields: '1' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const addFarm = () => {
    if (!newFarm.name || !newFarm.owner || !newFarm.location) return;

    const farm: Farm = {
      id: Math.random().toString(36).substr(2, 9),
      name: newFarm.name,
      owner: newFarm.owner,
      location: newFarm.location,
      plannedFields: parseInt(newFarm.plannedFields) || 1,
      fields: []
    };

    const updatedFarms = [...farms, farm];
    setFarms(updatedFarms);
    setShowModal(false);
    setNewFarm({ name: '', owner: '', location: '', plannedFields: '1' });
    setSelectedFarm(farm);
  };

  const handleExcelUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsImporting(true);
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = (window as any).XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const data = (window as any).XLSX.utils.sheet_to_json(ws);

        processImportedData(data);
      } catch (error) {
        console.error("Erro ao ler Excel:", error);
        alert("Erro ao processar o arquivo. Verifique o formato.");
      } finally {
        setIsImporting(false);
        if (fileInputRef.current) fileInputRef.current.value = '';
      }
    };
    reader.readAsBinaryString(file);
  };

  const processImportedData = (data: any[]) => {
    let currentFarms = [...farms];

    data.forEach((row: any) => {
      const owner = row.Cliente || row.Proprietario || 'Cliente Indefinido';
      const farmName = row.Fazenda || row.Propriedade || 'Fazenda S/N';
      const location = row.Localidade || row.Cidade || row.Localizacao || 'Não informada';
      const fieldName = row.Talhao || row.Lote || 'Talhão S/N';
      const area = parseFloat(row.Area || row.Hectares || '0');
      const crop = row.Cultura || 'Soja';
      const season = row.Safra || row.Ano || row.Temporada || '2023/24';
      const plannedTotal = parseInt(row.Total_Talhoes || row.Meta || '1');

      let farm = currentFarms.find(f => f.owner === owner && f.name === farmName);

      if (!farm) {
        farm = {
          id: Math.random().toString(36).substr(2, 9),
          name: farmName,
          owner: owner,
          location: location,
          plannedFields: plannedTotal,
          fields: []
        };
        currentFarms.push(farm);
      }

      // Adiciona o talhão se ele não existir para aquela safra específica
      if (!farm.fields.find(f => f.name === fieldName && f.season === season)) {
        const newField: Field = {
          id: Math.random().toString(36).substr(2, 9),
          name: fieldName,
          area: area,
          crop: crop,
          season: season,
          points: []
        };
        farm.fields.push(newField);
      }
    });

    setFarms(currentFarms);
    alert(`${data.length} registros processados com sucesso!`);
  };

  const removeFarm = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (farms.length <= 1) return;
    const updatedFarms = farms.filter(f => f.id !== id);
    setFarms(updatedFarms);
    if (selectedFarm.id === id) setSelectedFarm(updatedFarms[0]);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Clientes e Projetos Ativos</h2>
          <p className="text-sm text-slate-500">Gerencie a amostragem de solo com suporte a linha do tempo (Safras).</p>
        </div>
        <div className="flex space-x-3">
          <input type="file" ref={fileInputRef} onChange={handleExcelUpload} accept=".xlsx, .xls, .csv" className="hidden" />
          <button 
            onClick={() => fileInputRef.current?.click()}
            disabled={isImporting}
            className="bg-white border border-slate-200 text-slate-600 px-4 py-2 rounded-xl text-sm font-bold flex items-center space-x-2 transition-all shadow-sm hover:bg-slate-50 disabled:opacity-50"
          >
            {isImporting ? (
               <svg className="animate-spin h-4 w-4 text-emerald-600" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
            ) : (
              <svg className="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
            )}
            <span>{isImporting ? 'Processando...' : 'Importar Planilha'}</span>
          </button>
          
          <button 
            onClick={() => setShowModal(true)}
            className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center space-x-2 transition-all shadow-md active:scale-95"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
            </svg>
            <span>Novo Cliente</span>
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {farms.map(f => (
          <div 
            key={f.id} 
            onClick={() => setSelectedFarm(f)}
            className={`cursor-pointer rounded-2xl border-2 transition-all overflow-hidden ${
              selectedFarm.id === f.id ? 'border-emerald-500 bg-emerald-50/30 shadow-lg scale-[1.02]' : 'border-slate-200 bg-white hover:border-emerald-200 shadow-sm'
            }`}
          >
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-xl ${
                  selectedFarm.id === f.id ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-400'
                }`}>
                  {f.owner.charAt(0)}
                </div>
                <button onClick={(e) => removeFarm(f.id, e)} className="p-2 text-slate-300 hover:text-red-500 rounded-lg">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
              
              <h3 className="text-lg font-bold text-slate-800 mb-1">{f.name}</h3>
              <p className="text-xs font-semibold text-emerald-600 uppercase mb-2">Cliente: {f.owner}</p>
              <p className="text-xs text-slate-500 mb-4 flex items-center">
                <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" strokeWidth="2"/></svg>
                {f.location}
              </p>
              
              <div className="pt-4 border-t border-slate-100">
                <div className="flex justify-between items-end">
                   <div>
                    <p className="text-[10px] font-bold text-slate-400 uppercase">Talhões (Totais)</p>
                    <p className="text-lg font-bold text-slate-800">{f.fields.length} <span className="text-xs font-medium text-slate-400">Histórico</span></p>
                  </div>
                  <div className="text-right">
                    <p className="text-[9px] font-bold text-slate-400 mt-1 uppercase">Cronologia Ativa</p>
                    <p className="text-xs font-bold text-emerald-600">
                      {Array.from(new Set(f.fields.map(fld => fld.season))).length} Safra(s)
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100">
              <h3 className="text-xl font-bold text-slate-800">Novo Cadastro Manual</h3>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Nome da Fazenda</label>
                <input type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Ex: Sítio Arvoredo" value={newFarm.name} onChange={(e) => setNewFarm({...newFarm, name: e.target.value})} />
              </div>
              <div>
                <label className="block text-sm font-semibold text-slate-700 mb-1">Cliente / Proprietário</label>
                <input type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Nome Completo" value={newFarm.owner} onChange={(e) => setNewFarm({...newFarm, owner: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Cidade - UF</label>
                  <input type="text" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500" placeholder="Ex: Jataí - GO" value={newFarm.location} onChange={(e) => setNewFarm({...newFarm, location: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1">Meta Talhões</label>
                  <input type="number" className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500" value={newFarm.plannedFields} onChange={(e) => setNewFarm({...newFarm, plannedFields: e.target.value})} />
                </div>
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex space-x-3">
              <button onClick={() => setShowModal(false)} className="flex-1 py-3 text-sm font-bold text-slate-600 hover:bg-slate-200 rounded-xl">Cancelar</button>
              <button onClick={addFarm} className="flex-1 py-3 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-lg">Confirmar Cadastro</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FarmManager;
