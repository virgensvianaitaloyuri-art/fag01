
import React, { useState } from 'react';
import { Farm, SoilNutrients } from '../types';
import { analyzeSoilData } from '../services/geminiService';

interface AIAnalysisProps {
  farm: Farm;
}

const AIAnalysis: React.FC<AIAnalysisProps> = ({ farm }) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [inputNutrients, setInputNutrients] = useState<SoilNutrients>({
    ph: 5.8, p: 15, k: 0.3, mo: 3.2, ca: 4.5, mg: 1.5
  });

  const handleAnalyze = async () => {
    setLoading(true);
    setResult(null);
    try {
      const response = await analyzeSoilData(inputNutrients, farm.fields[0]?.crop || 'Soja');
      setResult(response || "Erro na geração.");
    } catch (e) {
      setResult("Erro ao conectar com o serviço de IA.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
        <h3 className="text-lg font-bold text-slate-800 mb-6">Informar Laudo de Solo</h3>
        <p className="text-sm text-slate-500 mb-8">Insira os resultados das médias coletadas em campo para receber uma prescrição agronômica inteligente.</p>
        
        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">pH (CaCl2)</label>
            <input 
              type="number" step="0.1"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500"
              value={inputNutrients.ph}
              onChange={(e) => setInputNutrients({...inputNutrients, ph: parseFloat(e.target.value)})}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Fósforo (P)</label>
            <input 
              type="number"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500"
              value={inputNutrients.p}
              onChange={(e) => setInputNutrients({...inputNutrients, p: parseFloat(e.target.value)})}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Potássio (K)</label>
            <input 
              type="number" step="0.01"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500"
              value={inputNutrients.k}
              onChange={(e) => setInputNutrients({...inputNutrients, k: parseFloat(e.target.value)})}
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Matéria Orgânica (%)</label>
            <input 
              type="number" step="0.1"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500"
              value={inputNutrients.mo}
              onChange={(e) => setInputNutrients({...inputNutrients, mo: parseFloat(e.target.value)})}
            />
          </div>
        </div>

        <button 
          onClick={handleAnalyze}
          disabled={loading}
          className="w-full mt-8 py-4 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center space-x-3 hover:bg-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-lg active:scale-95"
        >
          {loading ? (
            <svg className="animate-spin h-5 w-5 text-white" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
          ) : (
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          )}
          <span>{loading ? 'Analisando Solo...' : 'Gerar Recomendação IA'}</span>
        </button>
      </div>

      <div className="bg-slate-900 rounded-2xl p-8 text-white relative overflow-hidden min-h-[400px]">
        {/* Decorative BG element */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-600/10 blur-[100px] rounded-full"></div>
        
        <div className="relative z-10">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <h3 className="text-xl font-bold">Relatório Agronômico IA</h3>
          </div>

          {result ? (
            <div className="prose prose-invert prose-emerald max-w-none animate-in fade-in slide-in-from-right-4 duration-300">
              <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur-sm">
                <p className="text-slate-300 leading-relaxed whitespace-pre-wrap text-sm md:text-base">
                  {result}
                </p>
              </div>
            </div>
          ) : (
            <div className="h-[300px] flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-2">
                <svg className="w-8 h-8 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
              </div>
              <p className="text-slate-400 font-medium">Aguardando dados de entrada...</p>
              <p className="text-slate-500 text-xs max-w-xs mx-auto">Clique em 'Gerar Recomendação' para que nossa IA processe os níveis de fertilidade e forneça sugestões técnicas.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIAnalysis;
