
import React, { useState } from 'react';
import { Farm, Field } from '../types';

interface FieldManagerProps {
  farm: Farm;
  farms: Farm[];
  setFarms: (farms: Farm[]) => void;
}

const FieldManager: React.FC<FieldManagerProps> = ({ farm, farms, setFarms }) => {
  const [showModal, setShowModal] = useState(false);
  // Updated state to include season
  const [newField, setNewField] = useState({ name: '', area: '', crop: 'Soja', season: '2024/25' });

  const addField = () => {
    if (!newField.name || !newField.area || !newField.season) return;

    // Fixed: Added missing season property
    const field: Field = {
      id: Math.random().toString(36).substr(2, 9),
      name: newField.name,
      area: parseFloat(newField.area),
      crop: newField.crop,
      season: newField.season,
      points: []
    };

    const updatedFarms = farms.map(f => {
      if (f.id === farm.id) {
        return { ...f, fields: [...f.fields, field] };
      }
      return f;
    });

    setFarms(updatedFarms);
    setShowModal(false);
    setNewField({ name: '', area: '', crop: 'Soja', season: '2024/25' });
  };

  const removeField = (id: string) => {
    const updatedFarms = farms.map(f => {
      if (f.id === farm.id) {
        return { ...f, fields: f.fields.filter(field => field.id !== id) };
      }
      return f;
    });
    setFarms(updatedFarms);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-bold text-slate-800">Lista de Talhões</h2>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center space-x-2 transition-all shadow-md active:scale-95"
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
          </svg>
          <span>Novo Talhão</span>
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {farm.fields.map(field => (
          <div key={field.id} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden group hover:border-emerald-300 transition-colors">
            <div className="h-32 bg-slate-100 flex items-center justify-center relative">
              <div className="absolute top-2 right-2">
                <button 
                  onClick={() => removeField(field.id)}
                  className="p-1.5 bg-white/80 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg transition-colors"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                </button>
              </div>
              <svg className="w-16 h-16 text-slate-300 group-hover:text-emerald-200 transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 002 2 2 2 0 012 2v.657M16.5 7.697l.303.606a2.5 2.5 0 010 2.236l-.303.606" />
              </svg>
            </div>
            <div className="p-5">
              <h3 className="font-bold text-slate-800 text-lg mb-1">{field.name}</h3>
              <div className="flex items-center space-x-3 text-sm text-slate-500 mb-4">
                <span className="flex items-center space-x-1">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" strokeWidth="2" /></svg>
                  <span>{field.area} ha</span>
                </span>
                <span className="flex items-center space-x-1">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M5 13l4 4L19 7" strokeWidth="2" /></svg>
                  <span>{field.crop}</span>
                </span>
              </div>
              <div className="pt-4 border-t border-slate-100 flex justify-between items-center">
                <div className="flex -space-x-2">
                  <div className="w-7 h-7 rounded-full bg-emerald-500 border-2 border-white flex items-center justify-center text-[10px] text-white font-bold">A</div>
                  <div className="w-7 h-7 rounded-full bg-sky-500 border-2 border-white flex items-center justify-center text-[10px] text-white font-bold">B</div>
                  <div className="w-7 h-7 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center text-[10px] text-slate-400 font-bold">+{field.points.length}</div>
                </div>
                <span className="text-xs font-bold text-slate-400 uppercase">{field.points.length} Pontos</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center">
              <h3 className="text-lg font-bold text-slate-800">Cadastrar Novo Talhão</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Nome do Talhão</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  placeholder="Ex: Talhão Sul 01"
                  value={newField.name}
                  onChange={(e) => setNewField({...newField, name: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Área (ha)</label>
                  <input 
                    type="number" 
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    placeholder="0.00"
                    value={newField.area}
                    onChange={(e) => setNewField({...newField, area: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">Cultura</label>
                  <select 
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                    value={newField.crop}
                    onChange={(e) => setNewField({...newField, crop: e.target.value})}
                  >
                    <option>Soja</option>
                    <option>Milho</option>
                    <option>Algodão</option>
                    <option>Café</option>
                    <option>Cana</option>
                  </select>
                </div>
              </div>
              {/* Added Safra (Season) input field */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Safra</label>
                <input 
                  type="text" 
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
                  placeholder="Ex: 2024/25"
                  value={newField.season}
                  onChange={(e) => setNewField({...newField, season: e.target.value})}
                />
              </div>
            </div>
            <div className="p-6 bg-slate-50 flex space-x-3">
              <button 
                onClick={() => setShowModal(false)}
                className="flex-1 py-3 text-sm font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={addField}
                className="flex-1 py-3 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-md transition-all active:scale-95"
              >
                Criar Talhão
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FieldManager;
