
import React, { useState, useEffect } from 'react';
import { ViewState, Farm, SampleStatus, Field } from './types';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import SoilMap from './components/SoilMap';
import AIAnalysis from './components/AIAnalysis';
import FarmManager from './components/FarmManager';

const INITIAL_FARMS: Farm[] = [
  {
    id: '1',
    name: 'Fazenda Santa Maria',
    owner: 'João Medeiros',
    location: 'Uberlândia - MG',
    plannedFields: 5,
    fields: [
      {
        id: 'f1',
        name: 'Talhão Norte 01',
        area: 45,
        crop: 'Soja',
        // Added missing season property
        season: '2023/24',
        points: [
          { 
            id: 'PT-A1', 
            lat: -18.91, 
            lng: -48.27, 
            layers: [
              { depth: '0-20cm', status: SampleStatus.COMPLETED, nutrients: { ph: 5.5, p: 12, k: 0.25, mo: 2.5, ca: 3.2, mg: 1.1 } },
              { depth: '20-40cm', status: SampleStatus.PENDING }
            ],
            collectionDate: '2023-10-15' 
          }
        ]
      },
      {
        id: 'f2',
        name: 'Talhão Sul 05',
        area: 32,
        crop: 'Milho',
        // Added missing season property
        season: '2023/24',
        points: [
          { 
            id: 'PT-B1', 
            lat: -18.915, 
            lng: -48.275, 
            layers: [
              { depth: '0-20cm', status: SampleStatus.COLLECTED },
              { depth: '20-40cm', status: SampleStatus.PENDING }
            ]
          }
        ]
      }
    ]
  }
];

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<ViewState>('dashboard');
  const [farms, setFarms] = useState<Farm[]>(() => {
    const saved = localStorage.getItem('agrosolo_farms');
    return saved ? JSON.parse(saved) : INITIAL_FARMS;
  });
  const [selectedFarm, setSelectedFarm] = useState<Farm>(farms[0] || INITIAL_FARMS[0]);
  const [selectedField, setSelectedField] = useState<Field | null>(null);

  useEffect(() => {
    localStorage.setItem('agrosolo_farms', JSON.stringify(farms));
  }, [farms]);

  const handleUpdateFarms = (newFarms: Farm[]) => {
    setFarms(newFarms);
    const updatedSelected = newFarms.find(f => f.id === selectedFarm.id);
    if (updatedSelected) {
      setSelectedFarm(updatedSelected);
    } else if (newFarms.length > 0) {
      setSelectedFarm(newFarms[0]);
    }
  };

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return (
          <Dashboard 
            farms={farms} 
            setActiveView={setActiveView} 
            setSelectedField={setSelectedField} 
            setSelectedFarm={setSelectedFarm} 
          />
        );
      case 'farms':
        return <FarmManager farms={farms} setFarms={handleUpdateFarms} selectedFarm={selectedFarm} setSelectedFarm={setSelectedFarm} />;
      case 'samples':
        return <SoilMap farm={selectedFarm} setFarms={handleUpdateFarms} farms={farms} selectedField={selectedField} />;
      case 'analysis':
        return <AIAnalysis farm={selectedFarm} />;
      default:
        return (
          <Dashboard 
            farms={farms} 
            setActiveView={setActiveView} 
            setSelectedField={setSelectedField} 
            setSelectedFarm={setSelectedFarm} 
          />
        );
    }
  };

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      <Sidebar 
        activeView={activeView} 
        setActiveView={setActiveView} 
        selectedFarm={selectedFarm}
        setSelectedFarm={setSelectedFarm}
        farms={farms}
      />
      <main className="flex-1 overflow-y-auto relative p-4 md:p-8">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">
              {activeView === 'dashboard' && 'Painel de Operações'}
              {activeView === 'farms' && 'Gestão de Clientes'}
              {activeView === 'samples' && 'Mapeamento Georreferenciado'}
              {activeView === 'analysis' && 'Laudo Técnico IA'}
            </h1>
            <p className="text-slate-500 text-sm">
              {activeView === 'dashboard' ? 'Visão geral de todos os projetos' : (
                <>Operando em: <span className="font-bold text-emerald-600">{selectedFarm.owner}</span> • {selectedFarm.name}</>
              )}
            </p>
          </div>
          <div className="flex items-center space-x-2 bg-white px-4 py-2 rounded-2xl shadow-sm border border-slate-200">
            <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
            <span className="text-[10px] font-bold text-slate-600 uppercase tracking-widest">Serviço Ativo</span>
          </div>
        </header>

        {renderContent()}
      </main>
    </div>
  );
};

export default App;
