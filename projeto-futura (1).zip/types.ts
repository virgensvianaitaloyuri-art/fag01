
export enum SampleStatus {
  PENDING = 'Pendente',
  COLLECTED = 'Coletada',
  IN_LAB = 'No Laboratório',
  COMPLETED = 'Concluída'
}

export interface SoilNutrients {
  ph?: number;
  p?: number; // Fósforo (mg/dm³)
  k?: number; // Potássio (cmolc/dm³)
  mo?: number; // Matéria Orgânica (%)
  ca?: number; // Cálcio
  mg?: number; // Magnésio
}

export interface SampleLayer {
  depth: string; // ex: "0-20cm", "20-40cm"
  status: SampleStatus;
  nutrients?: SoilNutrients;
  labRef?: string; // Referência do saco/etiqueta para o laboratório
}

export interface SamplePoint {
  id: string;
  lat: number;
  lng: number;
  layers: SampleLayer[];
  collectionDate?: string;
}

export interface Field {
  id: string;
  name: string;
  area: number; // Hectares
  crop: string;
  season: string; // ex: "2023/24"
  points: SamplePoint[];
  boundary?: any; // Dados GeoJSON do contorno ou zonas
}

export interface Farm {
  id: string;
  name: string;
  owner: string; // Nome do Cliente
  location: string;
  plannedFields: number; // Quantidade de talhões prevista no contrato
  fields: Field[];
}

export type ViewState = 'dashboard' | 'farms' | 'samples' | 'analysis';
